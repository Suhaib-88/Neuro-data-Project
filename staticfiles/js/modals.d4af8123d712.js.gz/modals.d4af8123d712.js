function Check(that){
  if (that.value=='Import data from DataBase'){
      document.getElementById('div1').style.display="block";

  }
  else if (that.value=='Import data from file'){
      document.getElementById('div2').style.display="block";

  }
  else if (that.value=='Import data from cloud'){
      document.getElementById('div3').style.display="block";

  }
  else if (that.value=='Aggregate Component'){
      document.getElementById('div4').style.display="block";

  }
  else  if (that.value=='Balanced Data Distributor'){
      document.getElementById('div5').style.display="block";

  }
  else if (that.value=='Conditional Splitter'){
      document.getElementById('div6').style.display="block";

  }
  else if (that.value=='Data Conversion'){
      document.getElementById('div7').style.display="block";

  }
  else if (that.value=='Data Streaming Destination'){
      document.getElementById('div8').style.display="block";

  }
  else if (that.value=='Lookup Component'){
      document.getElementById('div9').style.display="block";

  }
  else if (that.value=='Merge Join Component'){
      document.getElementById('div10').style.display="block";

  }
  else if (that.value=='MultiCast Component'){
      document.getElementById('div11').style.display="block";

  }
  else if (that.value=='RowCount Component'){
      document.getElementById('div12').style.display="block";

  }
  else if (that.value=='Sort Component'){
      document.getElementById('div13').style.display="block";

  }
  else if (that.value=='Union All Component'){
      document.getElementById('div14').style.display="block";

  }
  else if (that.value=='Duplicate resolver Component'){
      document.getElementById('div15').style.display="block";

  }

  else if (that.value=='Audit Component'){
      document.getElementById('div16').style.display="block";

  }
  else if (that.value=='CDC Splitter'){
      document.getElementById('div17').style.display="block";

  }
  else if (that.value=='Character Map Component'){
      document.getElementById('div18').style.display="block";

  }
  else if (that.value=='Copy Column Component'){
      document.getElementById('div19').style.display="block";

  }
  else if (that.value=='Import Column Component'){
      document.getElementById('div20').style.display="block";

  }
  else if (that.value=='Percentage sampling Component'){
      document.getElementById('div21').style.display="block";

  }
  else if (that.value=='Pivot Component'){
      document.getElementById('div22').style.display="block";

  }
  else if (that.value=='Unpivot Component'){
      document.getElementById('div23').style.display="block";

  }
  else if (that.value=='Row Sampling Component'){
      document.getElementById('div24').style.display="block";

  }
  else if (that.value=='Derived Column Component'){
      document.getElementById('div25').style.display="block";

  }
  else{
      document.getElementById('div1').style.display="none";
      document.getElementById('div2').style.display="none";
      document.getElementById('div3').style.display="none";
      document.getElementById('div4').style.display="none";
      document.getElementById('div5').style.display="none";
      document.getElementById('div6').style.display="none";
      document.getElementById('div7').style.display="none";
      document.getElementById('div8').style.display="none";
      document.getElementById('div9').style.display="none";
      document.getElementById('div10').style.display="none";
      document.getElementById('div11').style.display="none";
      document.getElementById('div12').style.display="none";
      document.getElementById('div13').style.display="none";
      document.getElementById('div14').style.display="none";
      document.getElementById('div15').style.display="none";
      document.getElementById('div16').style.display="none";
      document.getElementById('div17').style.display="none";
      document.getElementById('div18').style.display="none";
      document.getElementById('div19').style.display="none";
      document.getElementById('div20').style.display="none";
      document.getElementById('div21').style.display="none";
      document.getElementById('div22').style.display="none";
      document.getElementById('div23').style.display="none";
      document.getElementById('div24').style.display="none";
      document.getElementById('div25').style.display="none";

  }
}
